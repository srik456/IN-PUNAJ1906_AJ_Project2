package com.cogni.smart_shop.service;

import com.cogni.smart_shop.bean.Register;

public interface RegisterService {
	
	public boolean insert(Register bean,String userType);

}
